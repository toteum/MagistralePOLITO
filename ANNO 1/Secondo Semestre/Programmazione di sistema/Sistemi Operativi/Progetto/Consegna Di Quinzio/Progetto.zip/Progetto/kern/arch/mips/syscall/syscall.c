/*
 * Copyright (c) 2000, 2001, 2002, 2003, 2004, 2005, 2008, 2009
 *	The President and Fellows of Harvard College.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the University nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE UNIVERSITY AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE UNIVERSITY OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

#include <types.h>
#include <kern/errno.h>
#include <kern/syscall.h>
#include <lib.h>
#include <mips/trapframe.h>
#include <thread.h>
#include <current.h>
#include <copyinout.h>
#include <syscall.h>
#include <addrspace.h>


/*
 * System call dispatcher.
 *
 * A pointer to the trapframe created during exception entry (in
 * exception-*.S) is passed in.
 *
 * The calling conventions for syscalls are as follows: Like ordinary
 * function calls, the first 4 32-bit arguments are passed in the 4
 * argument registers a0-a3. 64-bit arguments are passed in *aligned*
 * pairs of registers, that is, either a0/a1 or a2/a3. This means that
 * if the first argument is 32-bit and the second is 64-bit, a1 is
 * unused.
 *
 * This much is the same as the calling conventions for ordinary
 * function calls. In addition, the system call number is passed in
 * the v0 register.
 *
 * On successful return, the return value is passed back in the v0
 * register, or v0 and v1 if 64-bit. This is also like an ordinary
 * function call, and additionally the a3 register is also set to 0 to
 * indicate success.
 *
 * On an error return, the error code is passed back in the v0
 * register, and the a3 register is set to 1 to indicate failure.
 * (Userlevel code takes care of storing the error code in errno and
 * returning the value -1 from the actual userlevel syscall function.
 * See src/user/lib/libc/arch/mips/syscalls-mips.S and related files.)
 *
 * Upon syscall return the program counter stored in the trapframe
 * must be incremented by one instruction; otherwise the exception
 * return code will restart the "syscall" instruction and the system
 * call will repeat forever.
 *
 * If you run out of registers (which happens quickly with 64-bit
 * values) further arguments must be fetched from the user-level
 * stack, starting at sp+16 to skip over the slots for the
 * registerized values, with copyin().
 */
void
syscall(struct trapframe *tf)
{
    int callno;
    int32_t retval;
    int32_t retval_high;
    int err;

    KASSERT(curthread != NULL);
    KASSERT(curthread->t_curspl == 0);
    KASSERT(curthread->t_iplhigh_count == 0);

    callno = tf->tf_v0;

    /*
     * Most system calls return a single 32-bit value.
     */
    retval = 0;
    retval_high = 0;
    err = 0;

    switch (callno) {

        case SYS_reboot:
            err = sys_reboot(tf->tf_a0);
            break;


        case SYS___time:
            err = sys___time((userptr_t)tf->tf_a0,
                             (userptr_t)tf->tf_a1);
            break;


        /*
         * File-related system calls.
         */

        case SYS_open:
            err = sys_open((userptr_t)tf->tf_a0,
                           (int)tf->tf_a1,
                           (int)tf->tf_a2,
                           &retval);
            break;


        case SYS_read:
            err = sys_read((int)tf->tf_a0,
                           (userptr_t)tf->tf_a1,
                           (size_t)tf->tf_a2,
                           &retval);
            break;


        case SYS_write:
            err = sys_write((int)tf->tf_a0,
                            (userptr_t)tf->tf_a1,
                            (size_t)tf->tf_a2,
                            &retval);
            break;


        case SYS_close:
            err = sys_close((int)tf->tf_a0);
            break;


        case SYS_lseek:
        {
            off_t pos;
            off_t newpos;
            int whence;

            /*
             * lseek(int fd, off_t pos, int whence)
             *
             * fd occupies a0.
             *
             * Since off_t is 64 bit, it must start on an
             * aligned register pair. Therefore a1 is unused
             * and pos is passed in a2/a3.
             */
            pos = ((off_t)(uint32_t)tf->tf_a2 << 32) |
                  (off_t)(uint32_t)tf->tf_a3;

            /*
             * No argument register remains for whence.
             * Additional syscall arguments are stored on the
             * user stack after the four register argument slots.
             */
            err = copyin(
                (const_userptr_t)(tf->tf_sp + 16),
                &whence,
                sizeof(whence));

            if (err) {
                break;
            }

            err = sys_lseek((int)tf->tf_a0,
                            pos,
                            whence,
                            &newpos);

            if (!err) {

                /*
                 * lseek returns a 64-bit off_t through v0/v1.
                 */
                retval_high =
                    (int32_t)(((uint64_t)newpos >> 32)
                              & 0xffffffff);

                retval =
                    (int32_t)((uint64_t)newpos
                              & 0xffffffff);
            }

            break;
        }


        case SYS_dup2:
            err = sys_dup2((int)tf->tf_a0,
                           (int)tf->tf_a1,
                           &retval);
            break;


        case SYS_chdir:
            err = sys_chdir((userptr_t)tf->tf_a0);
            break;


        case SYS___getcwd:
            err = sys___getcwd((userptr_t)tf->tf_a0,
                               (size_t)tf->tf_a1,
                               &retval);
            break;


        /*
         * Process-related system calls.
         */

        case SYS_getpid:
            retval = sys_getpid();
            break;


        case SYS_fork:
        {
            pid_t child_pid;

            err = sys_fork(tf, &child_pid);

            if (!err) {
                retval = child_pid;
            }

            break;
        }


        case SYS_execv:
            err = sys_execv((userptr_t)tf->tf_a0,
                            (userptr_t)tf->tf_a1);
            break;


        case SYS_waitpid:
        {
            pid_t waited_pid;

            err = sys_waitpid((pid_t)tf->tf_a0,
                              (userptr_t)tf->tf_a1,
                              (int)tf->tf_a2,
                              &waited_pid);

            if (!err) {
                retval = waited_pid;
            }

            break;
        }


        case SYS__exit:

            /*
             * A successful _exit() never returns.
             */
            sys__exit((int)tf->tf_a0);

            panic("sys__exit returned\n");
            break;


        default:
            kprintf("Unknown syscall %d\n", callno);
            err = ENOSYS;
            break;
    }


    /*
     * Return the result to user mode.
     */
    if (err) {

        /*
         * On failure v0 contains errno and a3 signals an error.
         */
        tf->tf_v0 = err;
        tf->tf_a3 = 1;
    }
    else {

        /*
         * lseek is the only implemented syscall returning
         * a 64-bit value.
         */
        if (callno == SYS_lseek) {
            tf->tf_v0 = retval_high;
            tf->tf_v1 = retval;
        }
        else {
            tf->tf_v0 = retval;
        }

        tf->tf_a3 = 0;
    }


    /*
     * Advance beyond the syscall instruction.
     * Otherwise the syscall would execute again after returning
     * to user mode.
     */
    tf->tf_epc += 4;


    /*
     * System calls must not return with interrupts elevated
     * or spinlocks still held.
     */
    KASSERT(curthread->t_curspl == 0);
    KASSERT(curthread->t_iplhigh_count == 0);
}

/*
 * Enter user mode for a newly forked process.
 *
 * This function is provided as a reminder. You need to write
 * both it and the code that calls it.
 *
 * Thus, you can trash it and do things another way if you prefer.
 */

void enter_forked_process(struct trapframe *tf)
{
    struct trapframe child_tf;

    KASSERT(tf != NULL);

    /*
     * Copy the saved parent CPU state onto the child's
     * kernel stack and release the temporary heap copy.
     */
    child_tf = *tf;
    kfree(tf);

    /*
     * fork() returns 0 in the child.
     */
    child_tf.tf_v0 = 0;

    /*
     * a3 = 0 indicates a successful syscall.
     */
    child_tf.tf_a3 = 0;

    /*
     * Resume execution immediately after the fork syscall.
     */
    child_tf.tf_epc += 4;

    /*
     * Make the child's address space active before
     * returning to user mode.
     */
    as_activate();

    mips_usermode(&child_tf);

    panic("mips_usermode returned\n");
}