# OS/161 - Project c2: SHELL

Implementation of the OS/161 Project c2: SHELL, focused on file system calls and process management.

## Implemented System Calls

### File Management
- `open`
- `read`
- `write`
- `lseek`
- `close`
- `dup2`
- `chdir`
- `getcwd`

### Process Management
- `getpid`
- `fork`
- `execv`
- `waitpid`
- `_exit`

## Additional Features

- Standard file descriptors (`stdin`, `stdout`, `stderr`) initialized on `con:`
- Concurrent process execution
- Process exit status management
- PID allocation and reclamation
- Orphan process handling
- `WNOHANG` support for `waitpid`
- User process termination on fatal exceptions

## Testing

The implementation was tested using the OS/161 test programs, including:

- `badcall`
- `forktest`
- `multiexec`
- `bigseek`
- `redirect`

The `/bin/sh` shell was also used to test program execution, file operations, and background processes.