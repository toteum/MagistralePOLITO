.section .data

v1:         .byte 2, 6, -3, 11, 9, 18, -13, 16, 5, 1
v2:         .byte 4, 2, -13, 3, 9, 9, 7, 16, 4, 7
v3:         .space 10
v3_count:   .byte 0
flag1:      .byte 0
flag2:      .byte 0
flag3:      .byte 0

# The text section contains the instructions that the CPU runs.
.section .text
# Make _start visible as the point where the program begins.
.globl _start
_start:

    # Search for every v1 element in v2 and append matching values to v3.
    la x5, v1                 # x5 = address of v1
    la x6, v2                 # x6 = address of v2
    la x7, v3                 # x7 = next free position in v3
    li x10, 0                 # x10 = v3 length
    addi x18, x6, 10          # x18 = end of v2
    addi x19, x5, 10          # x19 = end of v1

v1_loop:
    beq x5, x19, compute_flags
    lb x11, 0(x5)             # x11 = current v1 value, sign extended
    add x13, x6, x0            # x13 = current v2 pointer

v2_loop:
    beq x13, x18, next_v1
    lb x14, 0(x13)            # x14 = current v2 value, sign extended
    beq x11, x14, found_match
    addi x13, x13, 1
    j v2_loop

found_match:
    sb x11, 0(x7)
    addi x7, x7, 1
    addi x10, x10, 1

next_v1:
    addi x5, x5, 1
    j v1_loop

compute_flags:
    la x15, v3_count
    sb x10, 0(x15)

    # An empty v3 sets only flag1.
    beq x10, x0, empty_v3

    la x15, flag1
    sb x0, 0(x15)
    la x16, flag2
    li x8, 1
    sb x8, 0(x16)
    la x17, flag3
    sb x8, 0(x17)

    # Check adjacent values for strict increase/decrease.
    la x7, v3
    li x8, 1
    lb x14, 0(x7)             # previous value
    addi x7, x7, 1

order_loop:
    beq x8, x10, End
    lb x11, 0(x7)             # current value

    blt x14, x11, increasing_ok
    sb x0, 0(x16)

increasing_ok:
    blt x11, x14, decreasing_ok
    sb x0, 0(x17)

decreasing_ok:
    addi x14, x11, 0
    addi x7, x7, 1
    addi x8, x8, 1
    j order_loop

empty_v3:
    la x15, flag1
    li x16, 1
    sb x16, 0(x15)
    la x15, flag2
    sb x0, 0(x15)
    la x15, flag3
    sb x0, 0(x15)

# The End block stops the program and returns control to the simulator.
End:
    li a0, 0
    li a7, 93
    ecall
