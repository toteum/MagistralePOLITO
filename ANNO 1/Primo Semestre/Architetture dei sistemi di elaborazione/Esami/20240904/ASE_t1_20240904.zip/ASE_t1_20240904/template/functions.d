.\functions.o: functions.s
