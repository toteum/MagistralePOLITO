.\sortfunction.o: sortFunction.s
